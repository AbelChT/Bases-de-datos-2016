DROP INDEX div_index;
DROP INDEX jorn_index;